export const PUBLIC_ROUTES:Record<string,string>={
    signIn: '/signIn',
    signUp: '/signUp'
}