'use client'
const Page=():React.ReactElement=> {
  return (
    <div> Page</div>
  )
}
export default Page