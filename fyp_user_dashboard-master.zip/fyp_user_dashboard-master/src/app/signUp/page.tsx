
import SignUpForm from "@/components/Forms/SignUp/signUp";
const Page=():React.ReactElement=>{
    return <div className="w-full h-full flex justify-center items-center">
            <SignUpForm/>
           </div>
}
export default Page;